# WoW: Forever Guild Platform — builder package v2.1 (Oct 25, 2026)

Everything discussed, organized for a builder agent or developer. No money anywhere in this project.

**Picking the project up in a new chat, or new to it?** Read `HANDOFF.md` first: decisions, status, to-dos and working agreements. **Builder agent?** Start with the reading order below. **Building on Replit?** The setup steps and phase prompts are in `14-replit-workflow.md`.

**v2.1 adds** `HANDOFF.md`, `14-replit-workflow.md`, the Forever Logs request text (appendix of `13-forever-logs-api.md`), and the Horde / RP-PvP decision. **What changed in v2.0:** the build is replanned around raid unlock (Wed Dec 9), not launch. The first milestone is a Dec 9 MVP (core, one-click raid night, attunement tracker, loot sheet) with a fixed gate on Tue Dec 1. Combat logs come from **Forever Logs** (Warcraft Logs has no Forever flavor), and the Classic Era proof of concept is reference material, no longer Phase 0.

## Read in this order
1. `00-BUILD_BRIEF.md` — the master prompt: what, why, principles, stack, phases, dependency status
2. `05-roadmap.md` — the Dec 9 MVP, dates, gates, the `events:read` decision point, cut list
3. `11-dependency-status.md` — dated log of every external dependency; check it before starting a phase
4. `01-architecture.md` — system shape, tenancy, jobs, security, longevity
5. `02-data-model.sql` — reference DDL for every module (translate to Drizzle)
6. `03-integrations.md` — adapter contracts for Discord, Raid-Helper, softres.it, logs, Talents Forever, wago, item sources, Gargul
7. `13-forever-logs-api.md` — the Forever Logs REST API: contract, scopes, access process, event semantics, footguns
8. `09-walkthrough.md` — one raid week with sample characters, showing how every module, table and job connects (read before building any cross-module feature)
9. `modules/A–J` — one spec per bounded context, each ending in acceptance criteria (A includes the attunement tracker; J = spreadsheet imports)
10. `06-acceptance-tests.md` — cross-cutting tests, including the Dec 1 MVP gate
11. `10-environments.md` — TEST (fixtures) vs FOREVER (production) configuration, adapter modes, cutover checklist
12. `test-data/` — mock dataset for TEST: roster, raid, wishlist and availability spreadsheets, seed, Discord/Raid-Helper/softres/Gargul/attunement fixtures, expectations
13. `07-strat-format.json` — boss strat JSON example (Phase 6)
14. `08-review-templates.md` — member-facing text rules (Phase 5)
15. `12-in-game-ui-alternatives.md` — what replaced WeakAuras under the Midnight addon rules, and what it means for members' UI and boss reminders
16. `14-replit-workflow.md` — building on Replit: one-time setup, the per-phase loop, secrets by phase, the Phase 1 prompt and a template for later phases
17. `HANDOFF.md` — for people and new chats, not the builder: decisions, status, to-dos, where each idea lives, name ideas for the reservation
18. `poc/` — **reference only.** Its metric spec and review templates are authoritative for Module C's math and text; its Warcraft Logs data layer is superseded by `13-forever-logs-api.md`

## Suggested first prompt to the builder
> Read 00-BUILD_BRIEF.md, 01-architecture.md, 02-data-model.sql, 03-integrations.md, 13-forever-logs-api.md and 09-walkthrough.md in full. Build Phase 1 per 05-roadmap.md and stop at its gate so I can verify with our real roster sheet. Then proceed phase by phase, stopping at each gate. The Dec 1 gate is fixed: if a phase runs long, use the roadmap's cut list rather than moving the date. Treat `poc/` as reference for Module C's metric math only; do not build it. Never hardcode game IDs; every derived number carries a patch; every external system goes through an adapter with a manual fallback.

## Before you start
- Discord server with a bot application (permissions in `03-integrations.md`), plus a separate test server
- Raid-Helper bot in the server and its API key
- Forever Logs account and API key (`stats:read`), with `events:read` requested (see the roadmap's weekend actions). Never paste the full key anywhere but the secret store; the visible `alog_` prefix is all anyone else needs.
- Postgres and object storage (R2) credentials
- Team list: names, **ruleset and faction** (decided Oct 25: Horde on RP-PvP for every team), raid days, roster sizes
- Loot method at raid unlock (default: SR + roll with attendance tie-breaks)
- The reservation roster sheet (reserved names in the `test-data/roster.xlsx` column layout), due Nov 3
- A spending cap per phase for whatever builder you use
- Optional: a Warcraft Logs API client, only to run the `poc/` math offline
