# Naxx Parse-Review PoC — package contents

> **Status (25 Oct 2026): reference only, not Phase 0.** Warcraft Logs has no Forever flavor; Forever's logs come from Forever Logs (`../13-forever-logs-api.md`). Keep `metrics-spec.md` and the review templates as the authority for Module C's metric math and review text. The Warcraft Logs data layer here (`wcl-queries.graphql`, Job B sampling, Era report fixtures) is superseded. Build this folder only as an optional offline test of the math; the platform build starts at Phase 1 in `../05-roadmap.md`.

Optional: to run it on its own, hand this folder to a builder, start the agent with the contents of `BUILD_BRIEF.md` as the first prompt, and tell it the other files are in the repo root.

| File | What it is |
|---|---|
| `BUILD_BRIEF.md` | The primary prompt: scope, stack, jobs A–H, UI pages, tests, acceptance criteria |
| `metrics-spec.md` | Exact metric definitions, swing analysis, bands, attribution, review templates + plain-language linter rules |
| `wcl-queries.graphql` | Reference queries for the Warcraft Logs v2 API |
| `schema.sql` | Reference Postgres DDL (translate to Drizzle) |
| `boss-config.json` | Patchwerk / Loatheb / Thaddius config, spec metric lists, weights, buckets |
| `consumes.json` | Consumable and world-buff names by category |
| `review-example.md` | Target output shape for one review |
| `.env.example` | Required environment variables |

## Before you start
1. Create a Warcraft Logs API client at https://www.warcraftlogs.com/api/clients/ and put the ID/secret in Replit Secrets.
2. Pick one public Classic Era Naxx report URL you'll use for ingest testing (any guild's public kill log with a few wipes is ideal).
3. Set `SAMPLE_PER_BAND=20` for the first run; raise it later.

## Suggested prompt to the builder
> Build this project exactly as described in BUILD_BRIEF.md. Read metrics-spec.md before writing the metric engine. Use the queries in wcl-queries.graphql as a starting point and fall back to GraphQL introspection when the live schema differs. Translate schema.sql into Drizzle. Load boss-config.json and consumes.json at startup. Work through the jobs in order A→H and stop after each milestone so I can verify with real data before continuing.

## Verification order
A (discovery) → B (rankings) → C (events) → D (bands) → E (ingest my report) → F (reviews) → G (lethality) → H (talents poller). Don't let the builder skip ahead: each step's output is the next step's input, and API points are finite.
